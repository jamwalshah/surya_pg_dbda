class MethOL {

    double result;
    double add()
    {
        int a=10;
        int b=20;
        result=a+b;
        return result;

    }
    int add(int p, int q)
    {
        result=p+q;
        return (int)result;
    }
    float add(float s, float t)
    {
        result=s+t;
        return (float) result;
    }

    public static void main(String[] args) {
        
        MethOL m1=new MethOL();
        double res;
        res=m1.add();
        System.out.println("Double result is:   "+res);
        int resint;
        resint=m1.add(100,200);
        System.out.println("Int result is:  "+resint);
        float resfloat;
        resfloat= m1.add(45.56f, 56.78f);
        System.out.println("Float result is:    "+resfloat);

    }
}
