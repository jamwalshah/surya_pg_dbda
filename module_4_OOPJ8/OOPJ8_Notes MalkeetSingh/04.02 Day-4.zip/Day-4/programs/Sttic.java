class Sttic {
    private int a;

    void setA(int b)
    {
        a=b;
    }
    int getA()
    {
        return a;
    }
    void Demo()
    {
        System.out.println("Value of a="+a);
    }


}
class StticTest
{
    public static void main(String[] args) {
        Sttic s1=new Sttic();
        s1.setA(100);
        s1.Demo();
    }
}