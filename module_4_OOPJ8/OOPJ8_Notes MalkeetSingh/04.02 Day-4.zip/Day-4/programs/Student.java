class Student {
    int Rno;
    String Name;
    String Address;

    void Setdata(int Rno, String Name, String Address)
    {
        this.Rno=Rno;
        this.Name=Name;
        this.Address=Address;
    }

    void Display()
    {
        System.out.println("Roll No:    "+Rno);
        System.out.println("Name:    "+Name);
        System.out.println("Address:    "+Address);
    }

    public static void main(String[] args) {
        Student s1= new Student();
        s1.Setdata(101, "Malkeet","Kharghar");  
        s1.Display();        
    }
    
}
