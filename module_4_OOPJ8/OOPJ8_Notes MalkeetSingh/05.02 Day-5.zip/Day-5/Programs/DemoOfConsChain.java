class DemoOfNPE {
    int a;   
    void Show()
    {
        System.out.println(a);
    }
}
class DemoOfConsChainTest
{
    public static void main(String[] args) {

        DemoOfNPE d1;
        d1.Show();

    }
}
