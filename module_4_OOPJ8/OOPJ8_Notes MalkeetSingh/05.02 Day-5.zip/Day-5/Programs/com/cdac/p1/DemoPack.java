package com.cdac.p1;
import java.util.*; //Non-static import of java.util package
import static java.lang.Math.PI; //Static import for the value of pi
class DemoPack {
    public static void main(String[] args) {
        System.out.println("Hello World");
        int area=(int)PI*22;
    }
    
}
