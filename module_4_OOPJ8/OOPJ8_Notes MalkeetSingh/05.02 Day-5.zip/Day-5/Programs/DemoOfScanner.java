import java.util.InputMismatchException;
import java.util.Scanner;
class DemoOfScanner {

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int a=0;
        System.out.println("Enter a int value");
        try{
            a=sc.nextInt();
        }
        catch(InputMismatchException ex)
        {
            System.out.println("Exception Catched"+ex.getMessage());
        }
        System.out.println("Program closed normally");
        
        System.out.println("Entered value is:   "+a);
    }

}
