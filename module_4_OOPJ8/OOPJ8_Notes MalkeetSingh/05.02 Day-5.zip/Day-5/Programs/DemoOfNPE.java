class DemoOfNPE {
    int a;   
    void Show()
    {
        System.out.println(a);
    }
}
class DemoOfNPETest
{
    public static void main(String[] args) {

        DemoOfNPE d1=new DemoOfNPE();
        d1.Show();
        d1=null;
        d1.Show();

    }
}
