import java.util.Scanner;
class Student
{
    int RollNo;
    String Name;
    String Address;

    void Setdata()
    {
        Scanner sc= new Scanner(System.in);
        Scanner scstr=new Scanner(System.in);
        System.out.println("Enter the Roll No:  ");
        RollNo=sc.nextInt();
        System.out.println("Enter the Name:     ");
        Name= scstr.nextLine();
        System.out.println("Enter the Address:     ");
        Address= scstr.nextLine();
    }
    void Display()
    {
        System.out.println("Student Information");
        System.out.println(RollNo+" "+Name+" "+Address);
    }

}
class DemoOfSc2Test {
public static void main(String[] args) {
    Student s1=new Student();
    s1.Setdata();
    s1.Display();
}

    
}
