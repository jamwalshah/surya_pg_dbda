import java.text.SimpleDateFormat;
import java.time.LocalDate;
class Date{
    int day;
    int month;
    int year;

    Date()
    {
        LocalDate ld= LocalDate.now();
        this.day=ld.getDayOfMonth();
        this.month=ld.getMonthValue();
        this.year=ld.getYear();
    }
}

class DemoofDate {
    public static void main(String[] args) {
        Date dt=new Date();
        System.out.println(dt.day+" "+dt.month+" "+dt.year);


    }
    
}
