## OOPJ Notes Day-5 (Date: 02/05/2023)
## Session-2 (4:00PM to 6:00PM)
### Eclipse introduction
- Kindly use seperrate workspace for your entire OOPJ Module
- make use of packages where ever applicable.
- Apply the Access Modifier whenever needed.
### implementing toString() method
### Array concept
### Array using Java
### NegativeArraySizeException
### ArraayIndexOutOfBoundsException
### foreach loop
### Passing array as a argument
### Creating array of primitive values/reference/instances
### java.util.Arrays
### Multi Dimensional array and Ragged array
### Enum
### Writing menu driven code using Enum