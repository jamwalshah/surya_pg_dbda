package com.cdac.mt;


class Demo implements Runnable
{

	@Override
	public void run() {
		for(int i=0;i<20;i++)
		{
		System.out.println("I am run of Demo");
		}
		//System.out.println(Thread.currentThread());
	}
	
}
class Demo1 implements Runnable
{

	@Override
	public void run() {
		for(int i=0; i<20;i++)
		{
		System.out.println("I am run of Demo1");
		}
		//System.out.println(Thread.currentThread());
	}
	
}
class Demo3 implements Runnable
{

	@Override
	public void run() {
		for(int i=0; i<20;i++)
		{
		System.out.println("I am run of Demo3");
		}
		//System.out.println(Thread.currentThread());
	}
	
}


public class MTThreadDemo{	

	public static void main(String[] args) {
		
		Runnable r1=new Demo();
		
		Runnable r2=new Demo1();
		Runnable r3=new Demo3();
		
		Thread t1=new Thread(r1, "Demo Class Thread");
		Thread t2=new Thread(r2, "Demo-2 class Thread");
		Thread t3=new Thread(r3, "Demo-3 class Thread");
		
		
		
		t1.start();
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t3.start();
		System.out.println("Now Running: "+Thread.activeCount());
		

	}

}
