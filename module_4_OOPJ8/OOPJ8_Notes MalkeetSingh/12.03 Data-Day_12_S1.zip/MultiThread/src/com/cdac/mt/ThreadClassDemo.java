package com.cdac.mt;

class Demo5 extends Thread
{	
	public static int a=30;
	
	synchronized public void Print()
	{
		System.out.println("Print");
	}
	/*
	@Override
	public void run()
	{
		for(int i=0;i<50;i++)
		{
			if(currentThread().getName()=="Thread 2")
			{
			a++;
			System.out.println("I am Running Thread of Demo5:  "+a+" ThreadName: "+currentThread());
			}
			else
			{
				a--;
				System.out.println("I am Running Thread of Demo5:  "+a+" ThreadName: "+currentThread());
			}
		}
	}
	*/
	@Override
	public void run()
	{
		for(int i=0;i<50;i++)
		{
			if(currentThread().getName()=="Thread 2")
			{
			System.out.println("I am Running Thread of Demo 5: ThreadName: "+currentThread());
			Print();
			}
			else
			{
				System.out.println("I am Running Thread of Demo5: ThreadName: "+currentThread());
				Print();
			}
		}
	}
}


public class ThreadClassDemo {

	public static void main(String[] args) {
		
		ThreadGroup tg=new ThreadGroup("Thread of Demo 5");
		Thread t1=new Demo5();
		t1.start();
		Thread t2=new Thread(tg,new Demo5(), "Thread 2");
		t2.start();
		
		

	}

}
