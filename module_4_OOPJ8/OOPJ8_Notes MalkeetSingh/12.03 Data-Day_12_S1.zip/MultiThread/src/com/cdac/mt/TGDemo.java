package com.cdac.mt;

class Demo2 implements Runnable
{

	@Override
	public void run() {
		for(int i=0;i<100;i++)
		{
			System.out.println("I am Running TH1");
			
		}
		
	}
	
}

public class TGDemo {

	public static void main(String[] args) {
		
		Runnable r1=new Demo2();
		
		ThreadGroup tg1=new ThreadGroup("Groupt-1");   //Creating a instance of new thread group
		
		Thread t1=new Thread(tg1,r1,"TH1");
		
		t1.start();
		try {
			System.out.println("TH is intrupted........");
			t1.interrupt();
			
		} catch (Exception ex) {
			
			ex.printStackTrace();
		}
		
		System.out.println("Name of Thread: "+t1.getName());
		System.out.println("Is Intrupted: "+t1.isInterrupted());
		System.out.println("Goup of Thread: "+t1.getThreadGroup());
		System.out.println("Is Alive "+t1.isAlive());
	}
}
