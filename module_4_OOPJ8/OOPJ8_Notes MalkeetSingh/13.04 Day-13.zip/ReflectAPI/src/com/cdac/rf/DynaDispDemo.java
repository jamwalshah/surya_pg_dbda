package com.cdac.rf;

abstract class A
{
	abstract void Show();

}
class B extends A
{
	void Show()
	{
		System.out.println("I am Show of B");
	}
}
class C extends B
{
	void Show()
	{
		System.out.println("I am Show of C");
	}
}
class D extends C
{
	void Show()
	{
		System.out.println("I am Show of D");
	}
}

public class DynaDispDemo {

	public static void main(String[] args) {
		//C c1=new D();
		A a1=new D();
		A a2=new C();
		D d1=new D();
		
		//d1.Show();
		
		a1.Show();
		a2.Show();

	}

}
