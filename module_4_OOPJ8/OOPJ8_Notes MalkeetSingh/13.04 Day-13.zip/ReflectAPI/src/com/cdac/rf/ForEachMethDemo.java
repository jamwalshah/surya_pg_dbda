package com.cdac.rf;

import java.util.ArrayList;

public class ForEachMethDemo {

	public static void main(String[] args) {
		
		
		
		ArrayList<Integer> list=new ArrayList<>();
		
		list.add(11);
		list.add(11);
		list.add(11);
		list.add(11);
		
		list.add(11);
		list.add(11);
		
		list.forEach(s->{System.out.println(s);} );   //For each method
	}

}
