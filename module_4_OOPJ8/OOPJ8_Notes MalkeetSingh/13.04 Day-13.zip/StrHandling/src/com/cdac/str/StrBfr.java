package com.cdac.str;

public class StrBfr {

	public static void main(String[] args) {
		
		
		
		StringBuffer s1=new StringBuffer("CDAC Mumbai");
		
		s1.append("Kharghar");
		System.out.println(s1);

	}

}
