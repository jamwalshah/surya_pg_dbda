package com.cdac.str;

import java.util.StringTokenizer;

public class StrTkn {

	public static void main(String[] args) {
		
		StringTokenizer stk=new StringTokenizer("I Love MY  India");
		
		
		System.out.println(stk.countTokens());
		
		
		while(stk.hasMoreElements())
		{
			System.out.println(stk.nextElement());
		}

	}

}
