package com.cdac.str;

public class StrD1 {

	public static void main(String[] args) {	
		String s1= new String("CDAC");   //s1 will refer to CDAC string value in Literal pool
		
		//s1="Mumbai";    //Now s1 will refer to MUMBai string value in literal pool.
		
		String s2=new String("CDAC"); // now s2 will refer to CDAC string value in Literal pool
		
		if(s1.equals(s2)) //Here equals method will compare the references of String Literal Pool to which s1 and s2 are refering in string Table
		{
			System.out.println("EQUAL");
		}
		else
		{
			System.out.println("NOT EQUAL");
		}
		
		System.out.println(s1.charAt(3));
		
		s1.concat(" Kharghar");
		
		System.out.println(s1.concat(" Kharghar"));
		
		
		System.out.println(s1.toLowerCase());
		
		
		if(s1.startsWith("C"))
		{
			System.out.println("String starts with C:");
		}
	}

}
