package com.cdac.ex;

public class DemoOfThrow {
	
	
	public static void show()
	{
		System.out.println("Am show method");
		throw new ArithmeticException("Arithmatic Exception thrown from Show");
	}

	public static void main(String[] args) {
		
		try
		{
			DemoOfThrow.show();
		}
		catch(ArithmeticException ex)
		{
			System.out.println(" Catch Block:   "+ex.getMessage());
		}
		finally {
		 System.out.println("Exception was there");
		}
		
		
		System.out.println("Am end of Main");

	}

}
