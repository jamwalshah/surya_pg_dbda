package com.cdac.ex;

public class ExChainDemo {

	public static void main(String[] args) {
		
		
		int a=10;
		int b=0;
		
		int c=0;
		
		try
		{
			c=a/b;
		}
		catch(ArithmeticException ex)
		{
			throw new ArithmeticException("Exp Chaining");
		}

	}

}
