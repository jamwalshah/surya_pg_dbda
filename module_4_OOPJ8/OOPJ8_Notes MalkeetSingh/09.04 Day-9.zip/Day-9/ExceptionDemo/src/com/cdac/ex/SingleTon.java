package com.cdac.ex;
class SingleDemo
{
	private static SingleDemo s1=null;
	
	private SingleDemo() 
	{
		
	}
	
	public static synchronized SingleDemo GetIns()
	{
		if(s1==null)
		{
			s1=new SingleDemo();
		}
		return s1;
	}
}
public class SingleTon {

	public static void main(String[] args) {
		
		SingleDemo s1=SingleDemo.GetIns();
		SingleDemo s2=SingleDemo.GetIns();
		SingleDemo s3=SingleDemo.GetIns();
		
		System.out.println("s1 Refering to:"+s1.hashCode());
		System.out.println("s2 Refering to:"+s2.hashCode());
		System.out.println("s3 Refering to:"+s3.hashCode());
		

	}

}
