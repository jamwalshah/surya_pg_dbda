package com.cdac.gn;

class Employee<T>
{
	T a;
	T b;
	
	String Name;
	
	
	void ShowData()
	{
		System.out.println(a+" "+b);
	}
	
}



public class GenDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e1=new Employee();
		
		e1.a="Malkeet";
		e1.b=45.68f;
		
		e1.ShowData();
		
		
		Employee e2=new Employee();
		
		e2.a=12;
		e2.b='C';
		
		
		
		e2.ShowData();
		
		
		Employee e3;
		
		e3=e2;
		

	}

}
