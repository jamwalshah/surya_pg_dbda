package com.cdac.cn;

import java.util.ArrayList;

public class WildCardDemo {
	
	public static void ShowList(ArrayList<?> list)
	{
		System.out.println(list);
	}

	public static void main(String[] args) {
		
		
		ArrayList<Integer> intlist=new ArrayList<Integer>();
		
		intlist.add(100);
		intlist.add(300);
		intlist.add(400);
		
		System.out.println("Displaying Int List");
		WildCardDemo.ShowList(intlist);
		 
		ArrayList<Float> flist=new ArrayList<Float>();
		
		flist.add(11.67f);
		flist.add(15.67f);
		flist.add(14.47f);
		flist.add(11.97f);
		System.out.println("Displaying Float List");
		WildCardDemo.ShowList(flist);
		
ArrayList<String> slist=new ArrayList<String>();
		
		slist.add("11.67f");
		slist.add("15.67f");
		slist.add("14.47f");
		slist.add("11.97f");
		System.out.println("Displaying Float List");
		WildCardDemo.ShowList(slist);
		

	}

}
