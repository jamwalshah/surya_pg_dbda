package com.cdac.cn;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {
	
	

	public static void main(String[] args) {
		ArrayList<Number> list=new ArrayList<Number>();  //Creating an instance of ArrayList Collection Class for upper bounded objects

		list.add(10101);
		list.add(45.56f); //list.add(new Float(45.56f))
		
		ArrayList<Integer> intlist=new ArrayList<Integer>();
		
		intlist.add(101);
		intlist.add(102);
		intlist.add(103);
		intlist.add(104);
		
		//Adding intlist to list
		
		list.addAll(intlist);
		
		//System.out.println(liststr);	
			
		//foreach loop
		
		for(Number n: list)
		{
			System.out.println(n);
		}
		intlist.clear();
		System.out.println("intList after clear");
		//main list after intlist cleared
		for(Integer n: intlist)
		{
			System.out.println(n);
		}
		//Itrator 
		Iterator<Number> it=list.iterator();
		System.out.println("Display the information using Itrator");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
	}
public static void main1(String[] args) {
		
		ArrayList<String> liststr=new ArrayList<String>();  //Creating an instance of ArrayList Collection Class

		liststr.add("Ram");
		liststr.add("Sham");
		liststr.add("Sohan");
		liststr.add("Mohan");
		liststr.add("Soham");
		liststr.add(2, "Sita");
		
		//Println Method
		
		//System.out.println(liststr);	
			
		//foreach loop
		
		for(String s: liststr)
		{
			System.out.println(s);
		}
	}

}
