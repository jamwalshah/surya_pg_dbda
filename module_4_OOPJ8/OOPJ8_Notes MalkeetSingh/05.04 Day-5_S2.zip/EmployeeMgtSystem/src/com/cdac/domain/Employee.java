package com.cdac.domain;

public class Employee 
{
	private int EmpId;
	private String EmpName;
	private long MobileNo;
	private String Address;
	private String EmailId;
	
	public Employee() {
		super();
	}

	public Employee(int empId, String empName, long mobileNo, String address, String emailId) {
		super();
		EmpId = empId;
		EmpName = empName;
		MobileNo = mobileNo;
		Address = address;
		EmailId = emailId;
	}

	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		EmpId = empId;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public long getMobileNo() {
		return MobileNo;
	}

	public void setMobileNo(long mobileNo) {
		MobileNo = mobileNo;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	@Override
	public String toString() {
		return "Employee [EmpId=" + EmpId + ", EmpName=" + EmpName + ", MobileNo=" + MobileNo + ", Address=" + Address
				+ ", EmailId=" + EmailId + "]";
	}
}
