package com.cdac.main;

import com.cdac.impl.EmployeeImpl;

public class EmployeeImplTest {

	public static void main(String[] args) {
		
		EmployeeImpl test1=new EmployeeImpl();
		
		test1.AcceptRecord();
		test1.PrintRecord();
	}

}
