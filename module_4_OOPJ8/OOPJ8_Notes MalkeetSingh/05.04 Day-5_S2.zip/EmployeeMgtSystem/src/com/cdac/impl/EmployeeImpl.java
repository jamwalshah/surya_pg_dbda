package com.cdac.impl;

import java.util.Scanner;

import com.cdac.domain.Employee;

public class EmployeeImpl {
	Employee e1=new Employee();
	
	public EmployeeImpl() {

			}
	public void AcceptRecord()
	{
		Scanner sc=new Scanner(System.in);
		Scanner scstr=new Scanner(System.in);
		System.out.println("Enter Employee Id");
		//int a=sc.nextInt(); //no need we can directly
		e1.setEmpId(sc.nextInt());
		System.out.println("Enter Employee Name");
		e1.setEmpName(scstr.nextLine());
		System.out.println("Enter Employee Mobile No");
		e1.setMobileNo(sc.nextLong());
		System.out.println("Enter Employee Address");
		e1.setAddress(scstr.nextLine());
		System.out.println("Enter Employee EmailId");
		e1.setEmailId(scstr.nextLine());
		sc.close();
		scstr.close();

	}
	public void PrintRecord()
	{
		System.out.println(e1.toString());
	}

}
