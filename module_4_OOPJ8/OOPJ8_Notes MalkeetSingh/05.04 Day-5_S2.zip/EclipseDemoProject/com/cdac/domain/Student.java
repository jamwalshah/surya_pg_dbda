package com.cdac.domain;

public class Student {
	int RollNo;
	String Name;
	
	public Student()
	{
		RollNo=1001;
		Name="Malkeet";
		
	}
	public void Display()
	{
		System.out.println("Student Infomation");
		System.out.println(RollNo+" "+Name);
	}

}
