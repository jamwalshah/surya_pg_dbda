package com.cdac.main;

import com.cdac.domain.Student;

public class StudentTest {

	public static void main(String[] args) {
		
		Student s1=new Student();
		s1.Display();
		

	}

}
