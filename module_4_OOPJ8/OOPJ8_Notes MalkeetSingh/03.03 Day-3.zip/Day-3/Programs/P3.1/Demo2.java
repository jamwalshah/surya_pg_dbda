class Demo2 {
    public static void main(String[] args)
    {
    Integer a1= new Integer(10); //Boxing with constructor of Integer Class
    int a=a1.intValue();
    System.out.println("Auto un-boxing of a1="+a);
    }
}
