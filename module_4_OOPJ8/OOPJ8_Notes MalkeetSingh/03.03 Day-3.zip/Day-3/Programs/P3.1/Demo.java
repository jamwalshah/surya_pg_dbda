class Demo
{
public static void main(String[] args)
{
int a=10;
Integer a1= new Integer(a); //Boxing with constructor of Integer Class
Integer a2=a; //auto-boxing 
System.out.println("Boxing of a with constructor="+a1);
System.out.println("Auto Boxing of a="+a2);
String s="12345677888990";
Integer a3=new Integer(s); //Boxing of string object/instance into Integer class object/instance
System.out.println("Boxing of string s="+a3);
}
}