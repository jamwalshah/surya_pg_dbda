class Demo3 {
public static void main(String args[])
{
    System.out.println("Argument Passed="+args[0]);
    System.out.println("Argument Passed="+args[1]);
}
}
