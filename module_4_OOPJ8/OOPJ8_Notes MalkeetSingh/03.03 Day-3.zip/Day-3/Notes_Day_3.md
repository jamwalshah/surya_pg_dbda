# Day-3 Date: 29/04/2023
## OOPJ Notes
### Boxing and Un-Boxing Implementation
- boxing: wrapping of a primitive data into wrapper class instance (object form);
```java
class Demo
{
public static void main(String[] args)
{
int a=10;
Integer a1= new Integer(a); //Boxing with constructor of Integer Class
Integer a2=a; //auto-boxing 
System.out.println("Boxing of a with constructor="+a1);
System.out.println("Auto Boxing of a="+a2);
String s="12345677888990";
Integer a3=new Integer(s); //Boxing of string object/instance into Integer class object/instance
System.out.println("Boxing of string s="+a3);
}
}
```
- Unboxing: Extracting the value from the instance of wrapper class into primitive data type
```java
class Demo2 {
    public static void main(String[] args)
    {
    Integer a1= new Integer(10); //Boxing with constructor of Integer Class
    int a=a1.intValue();
    System.out.println("Auto un-boxing of a1="+a);
    }
}
```
### NumberFormatException
- It arises when when we pass alphanumeric value to the  number family wrapper class.
- Do well defined examples on this
### Command line arguments
- These are list of arguments which can be passed to .class while executing that file with JVM
```java
class Demo3 {
public static void main(String args[])
{
    System.out.println("Argument Passed="+args[0]);
    System.out.println("Argument Passed="+args[1]);
}
}
```
### Java language Features
1. Simple (Easily readable or understanable)
2. Fast and Efficent (with the presence of JIT Compiler)
3. Robust
4. Portable
5. Architecture Neutral
6. Reliable
7. Object-Oriented (Study about Major and Minor pillers of OOPs model)
- so on....

### Demo of Classes  (Scanner, Date, Calendar, LocalDate, LocalTime, LocalDateTime and SimpleDateFormat)
### Class and its elements
#### Class
- Its a blueprint. 
```java
class Student 
{
    int RollNo;      //Intance varible-1 (DM of class)
    String Name;    //Intance varible-2
    String Address;     //Intance varible-3

    Student()
    {
        RollNo=1001;
        Name="Malkeet Singh";
        Address="CDCA Khrghar";
    }

    //Display function who is gonna print instace varibles for the particuler instance
    void Display()
    {
        System.out.println("RollNo="+RollNo);
        System.out.println("Name="+Name);
        System.out.println("Address="+Address);
    }
    public static void main(String args[])
    {
        //s1 is the reference variable of the class student to whom an instance of class is assigned
        Student s1=new Student(); //User defined default constructor
        Student s2=new Student();
        s2.RollNo=1002;
        s2.Name="ABC";
        s2.Address="Mumbai";
        s1.Name="Sandeep";

        s1.Display();
        s2.Display();
    }
}
```
#### field
#### method
#### reference
#### Instance
#### instance initializer block
#### Method Overloading
#### Constructor
#### Constructor chaining
#### NullPointerException
