class Student 
{
    int RollNo;      //Intance varible-1 (DM of class)
    String Name;    //Intance varible-2
    String Address;     //Intance varible-3

    Student()
    {
        RollNo=1001;
        Name="Malkeet Singh";
        Address="CDCA Khrghar";
    }

    //Display function who is gonna print instace varibles for the particuler instance
    void Display()
    {
        System.out.println("RollNo="+RollNo);
        System.out.println("Name="+Name);
        System.out.println("Address="+Address);
    }
    public static void main(String args[])
    {
        //s1 is the reference variable of the class student to whom an instance of class is assigned
        Student s1=new Student(); //User defined default constructor
        Student s2=new Student();
        s2.RollNo=1002;
        s2.Name="ABC";
        s2.Address="Mumbai";
        s1.Name="Sandeep";

        s1.Display();
        s2.Display();
    }
}
