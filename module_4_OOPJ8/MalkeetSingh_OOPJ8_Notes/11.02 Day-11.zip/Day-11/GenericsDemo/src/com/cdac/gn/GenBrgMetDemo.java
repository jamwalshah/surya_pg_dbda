package com.cdac.gn;

class DemoBr<T>
{
	private T a;
	
	public T GetA()
	{
		return a;
	}
	
	void SetData(T a)
	{
		this.a=a;
	}
}

class DemoBr2<T> extends DemoBr<T>
{
	T b;
	DemoBr<T> b1=new DemoBr<T>();
	void SetData(T b, T a)
	{
		this.b=b;
		b1.SetData(a);
	}
	void ShowData()
	{
		System.out.println(b1.GetA()+" "+b);
	}
}

public class GenBrgMetDemo {

	public static void main(String[] args) {
	
		DemoBr2 d1=new DemoBr2();
	
		d1.SetData("Hello", "Hii");
		
		d1.ShowData();
		

	}

}
