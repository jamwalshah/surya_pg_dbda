package com.cdac.gn;

class Employee<T>
{
	T a;
	T b;
	
	void SetData(T p, T q)
	{
		a=p;
		b=q;
	}
	void ShowData()
	{
		System.out.println(a+" "+b);
	}
	
}


public class GenDemo {

	public static void main(String[] args) {
		
		Employee e1=new Employee();
		
		Employee e2=new Employee();
		
		e1.SetData(11,12);
		e1.ShowData();
		
		e2.SetData(45.56f, 36.78);
		
		e2.ShowData();
		

	}

}
