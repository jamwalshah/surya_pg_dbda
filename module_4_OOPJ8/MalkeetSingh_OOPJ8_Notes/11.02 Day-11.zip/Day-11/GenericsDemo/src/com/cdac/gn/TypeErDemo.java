package com.cdac.gn;

/*
class Demo<T extends Number>
{
	T a;
	
	void SetData(T a)
	{
		this.a=a;
	}
	void ShowData()
	{
		System.out.println("Value of a:"+a);
	}
}
*/
class Demo<Number>
{
	Number a;
	
	void SetData(Number a)
	{
		this.a=a;
	}
	void ShowData()
	{
		System.out.println("Value of a:"+a);
	}
}

public class TypeErDemo {

	public static void main(String[] args) {
		
		Demo d1=new Demo();
		
		d1.SetData("String");  //not valid
		
		d1.SetData(1121);
		
		d1.ShowData();

	}

}
