package com.cdac.mt;

public class ThreadEnumDemo {

	public static void main(String[] args) {


		Thread t1=new Thread("My Thread");
		 
		t1.start();
		
		System.out.println(t1.getName()+" "+t1.getPriority()+" "+t1.getState());
		
		System.out.println(Thread.currentThread());

	}

}
