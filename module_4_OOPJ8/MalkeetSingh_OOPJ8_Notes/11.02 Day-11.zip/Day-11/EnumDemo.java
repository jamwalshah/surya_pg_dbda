enum Colors{Red, White,Green};
public class EnumDemo {
	
    enum Colors{Red, White,Green};
	public static void main(String[] args) {

		for(Colors c: Colors.values())
		{
			System.out.println(c);
		}
		
		System.out.println(Colors.valueOf("White").ordinal());
		
	}

}
