import java.io.File;

class FileMetdataRead {

    public static void main(String[] args) {
        
    String pathname="abc.txt";
    File f=new File(pathname);

    if(f.exists())
    {
        System.out.println(f.getName());
        System.out.println(f.lastModified());
        System.out.println(f.getPath());
    }
    }
    
    
}
