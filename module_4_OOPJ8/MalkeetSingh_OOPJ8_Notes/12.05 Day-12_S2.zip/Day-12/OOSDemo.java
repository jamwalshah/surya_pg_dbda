import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class St implements Serializable
{
    public int RollNo;
    public String Name;
    public St(int r, String n)
    {
        RollNo=r;
        Name=n;
    }

}
class OOSDemo 
{
    public static void main(String[] args) {
        St s1=new St(1001,"Malkeet");

        String path="abc.txt";

        FileOutputStream fout=null;
        FileInputStream fin=null;
        ObjectOutputStream oout=null;
        ObjectInputStream oin=null;
        try {
            fout=new FileOutputStream(path);
            fin=new FileInputStream(path);
        } catch (FileNotFoundException e) {
            System.out.println("Can't Read and Write to file");
        }

        File f=new File(path);
        try {
            oout=new ObjectOutputStream(fout);
              oout.writeObject(s1);
        } catch (IOException e) {
            System.out.println("Cant serilalize");
        }

        try {
            oin=new ObjectInputStream(fin);

            try {
                
                St obj;
                obj=(St)oin.readObject();

                System.out.println("Roll No: "+obj.RollNo+" Name: "+obj.Name);

            } catch (ClassNotFoundException e) {
                System.out.println("Can't Deserliaze");
            }


        } catch (IOException e) {
            System.out.println("Can Read File");
        }
        

    }
}
