import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

class FileDataReadDemo {
    
    public static void main(String[] args) {
        
        String path="abc.txt";

        FileInputStream fin=null;

        try {
            fin=new FileInputStream(path);

            try {
                while(fin.read()!=-1)
                {
                    System.out.println(fin.read());
                }
            } catch (IOException e) {
                System.out.println("Cant read");
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not found");
        }
    }
}
