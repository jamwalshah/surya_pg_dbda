import java.io.File;
import java.io.IOException;

class FileClassDemo {

    public static void main(String[] args) {
        //String pd="C:Users\\hp\\Desktop\\Dir\\File\\";
        String path="abc.txt";

        File f=new File(path);
        
        try{
            f.createNewFile();
            System.out.println("File Created");
        }
        catch(IOException ex)
        {
            System.out.println("File not created"+ex.getMessage());
        }
            
    }
}

