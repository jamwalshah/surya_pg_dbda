import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

class FileDataWriteDemo 
{
    public static void main(String[] args) {
        
        String path="abc.txt";

        FileOutputStream fout=null;

        try {
            fout=new FileOutputStream(path);
            
            byte[] b={80,81,85,90};

            try {
                fout.write(b);
            } catch (IOException e) {
                System.out.println("Data not written");
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }
    }
}
