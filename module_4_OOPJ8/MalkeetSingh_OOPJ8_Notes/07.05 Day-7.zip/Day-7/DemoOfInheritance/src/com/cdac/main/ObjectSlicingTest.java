package com.cdac.main;

class A
{
	int a=2;
	int b=3;
	int e=123;
}
class B extends A
{
	int c;
	int d;
}

class ObjectSlicingTest {

	public static void main(String[] args) {
		A a1=new A();
		
		B b1=new B();
				
		b1.a=10;
		b1.b=30;
		b1.c=40;
		b1.d=50;
		System.out.println("Value inside b1:");
		System.out.println(b1.a+" "+b1.b+" "+b1.c+" "+b1.d);
		a1=b1;
		
		System.out.println("Value inside a1:");
		System.out.println(a1.a+" "+a1.b+" "+a1.e);
		
		
		
		
	}

}
