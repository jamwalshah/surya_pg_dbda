package com.cdac.main;

class SingleInherit {
	
	int a;
	
	SingleInherit() 
	{
		System.out.println("Am a Default user defined constructor of parent class");	
	}
	
	void Getdata()
	{
		
		System.out.println("Am Get data of Parent class"+a);
	}
	void SetData()
	{
		System.out.println("Am Set data of Parent class");
	}

}

class SingleInheritChild extends SingleInherit
{
	int b;
	public SingleInheritChild() 
	{
	super(); //
	System.out.println("Am def cons of child class");
	}
	void gdata()
	{
		//super.Getdata();
		System.out.println("Am g data of child class"+b);
	}
	void sData()
	{
		
		System.out.println("Am s data of child class");
	}
	
}
 class SingleInheritTest
 {
	 public static void main(String args[])
	 {
		 SingleInheritChild ch1=new SingleInheritChild();
		 
		 ch1.a=10;
		 ch1.b=20;
		 ch1.gdata();

		 
	 }
 }
