package com.cdac.main;

public class MethodOverTest {

	public static void main(String[] args) {

		//Student s1=new Student(); //Ref and Instance of parent class
		
		//Student ref;   //Ref of parent class
		
		StudentInfo ref;
		ref=new Admin();  //Assigning instance of Admin(child) class to the parent class ref
		
		ref.AcceptRecord();
		ref.PrintRecord();
		
		
	}

}
