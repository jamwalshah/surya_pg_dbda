package com.cdac.main;

import java.util.Scanner;

class Admin extends StudentInfo
{
	String CourseName;
	
	void AcceptRecord()
	{
		//super.AcceptRecord();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Course Name:");
		CourseName=sc.nextLine();
		
	}
	void PrintRecord()
	{
		//super.PrintRecord();
		System.out.println("Course Information:");
		System.out.println(CourseName);
		
	}
}
