package com.cdac.main;

import java.util.Scanner;

public class StudentInfo extends Student{
	
	
	
	void AcceptRecord() 
	{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the Roll No:");
			RollNo=sc.nextInt();
			System.out.println("Enter the Fees:");
			fees=sc.nextInt();	
	}
	void PrintRecord()
	{
		System.out.println("Student Information");
		System.out.println(RollNo+"    "+fees);
	}



}
