package com.cdac.main;

import java.util.Scanner;

abstract class Student {
	int RollNo;
	int fees;
	abstract void AcceptRecord();
	abstract void PrintRecord();


}
