package com.cdac.main;

class Shape
{
	void Area()
	{
		System.out.println("Am Area of Shape");
	}
}
class Circle extends Shape
{
	void Area()
	{
		System.out.println("Am Area of circle");
	}
}
class Rectangle extends Shape
{
	void Area()
	{
		System.out.println("Am Area of Rect");
	}
}


class HierInheritDemo {

	public static void main(String[] args) {
	

		Shape sp1=new Circle();
		
	}

}
