//package P3;
class Demo
{ 
    //Concept of Explicit Convertion
public static void main (String args[])
{
    int a=159; //00000000 00000000 000001010 00000110
    byte b=(byte)a;  //0000000
    //short s=b;  // Binary 00000000 00001010 
    System.out.println(b);
}
}
