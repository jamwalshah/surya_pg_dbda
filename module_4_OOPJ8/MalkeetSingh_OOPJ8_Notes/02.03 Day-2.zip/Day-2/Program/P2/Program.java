//package P2;
class Program
{
    public static void main(String args[])
    {

        int a;
        System.out.println(a);

    }
}