package com.cdac.inter;

interface A1
{
	void get();
}
interface A2
{
	void get();
	void show();
}

class DemoOfInterface implements A1,A2
{
	public void get()
	{
		System.out.println("Hello i am implmented method get of A1");
	}
	public void show()
	{
		System.out.println("Hello i am implmented method show of A2");
	}

	public static void main(String[] args) {
		DemoOfInterface d1=new DemoOfInterface();
		
		d1.get();
		d1.show();

	}

}
