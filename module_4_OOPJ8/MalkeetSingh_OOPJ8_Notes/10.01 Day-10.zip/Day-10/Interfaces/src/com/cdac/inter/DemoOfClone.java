package com.cdac.inter;

class Emp implements Cloneable
{
	int EmpId;
	String EmpName;
	public Emp(int empId, String empName) {
		super();
		EmpId = empId;
		EmpName = empName;
	}
	@Override
	public String toString() {
		return "Emp [EmpId=" + EmpId + ", EmpName=" + EmpName + "]";
	}
	
	
	
}

public class DemoOfClone {

	public static void main(String[] args) {
		
		Emp e1=new Emp(1001, "ABC");
		
		System.out.println("Emp e1:   "+e1.toString());
		
		Emp e2=e1;
		System.out.println("Emp e2:    "+e2.toString());
		
		e1.EmpName="xyz";
		
		System.out.println("Emp e1:   "+e1.toString());
		System.out.println("Emp e2:    "+e2.toString());

	}

}
