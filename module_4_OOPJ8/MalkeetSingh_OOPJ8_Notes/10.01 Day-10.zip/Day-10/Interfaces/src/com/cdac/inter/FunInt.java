package com.cdac.inter;

interface A  //Functional Interface
{
	void get(); //abstract public void get();
	
	default void set()
	{
		System.out.println("Am Default def of set() of Interface A");
	}
}

class IntA implements A
{
	public void get()   //Defination of get() of Interface A
	{
		System.out.println("Im get of Interface A implented in class IntA");
	}
}

public class FunInt {

	public static void main(String[] args) {
		
		IntA a=new IntA();
		a.get();    //Calling of get() by instance of IntA
		
		a.set();   //default deffination of Default method is fetched 

	}

}
