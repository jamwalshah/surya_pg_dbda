package com.cdac.cn;

import java.util.Enumeration;
import java.util.Vector;

public class CollVecDemo {

	public static void main(String[] args) {
		
		Vector<Integer> v1=new Vector<Integer>(); //Declaration of Vector collection
		
		v1.add(10);
		v1.add(20);
		v1.add(10);
		v1.add(20);
		v1.add(10);
		v1.add(20);
		
		System.out.println("Print vector using for-each");
		
		for(Integer in: v1)
		{
			System.out.println(in);
		}
		
		
		System.out.println("Print vector using Enumaration");
		
		Enumeration<Integer> em=v1.elements();
		
		while(em.hasMoreElements())  //hasnext() method like Itrator
		{
			Integer in=em.nextElement();  //next() method like Itrator
			System.out.println(in);
		}
	}

}
