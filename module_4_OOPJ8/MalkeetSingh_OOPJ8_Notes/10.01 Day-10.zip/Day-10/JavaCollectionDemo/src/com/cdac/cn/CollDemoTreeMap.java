package com.cdac.cn;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeMap;

public class CollDemoTreeMap {

	public static void main(String[] args) {
		
		
		TreeMap<Integer, String> tm=new TreeMap<Integer, String>();
		
		tm.put(101, "Malkeet");
		tm.put(105, "Malkeet");
		tm.put(103, "Malkeet");
		tm.put(104, "Malkeet");
		
		System.out.println(tm);
		
		Collection<String> cl=tm.values();
		
		System.out.println(cl);
	
		

	}

}
