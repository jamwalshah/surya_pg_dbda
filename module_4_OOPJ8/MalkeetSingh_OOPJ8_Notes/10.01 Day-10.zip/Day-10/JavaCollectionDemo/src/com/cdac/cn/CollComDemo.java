package com.cdac.cn;

import java.util.ArrayList;
import java.util.Comparator;

class Employee
{
	int EmpId;
	String EmpName;
	
	Employee(int empid, String empname) 
	{
		EmpId=empid;
		EmpName=empname;
	}
}

class CompareEmpByEmpId implements Comparator<Employee>
{

	@Override
	public int compare(Employee e1, Employee e2) {
		
		if(e1.EmpId>e2.EmpId)
		{
			return 1;
		}
		if(e1.EmpId<e2.EmpId)
		{
			return -1;
		}
		return 0;
	}
	
}

public class CollComDemo {

	public static void main(String[] args) {
		
		Employee e1=new Employee(101, "Malkeet Singh");
		
		ArrayList<Employee> emplist=new ArrayList<Employee>();
		
		emplist.add(e1);
		
		emplist.add(new Employee(103, "Sandeep Singh"));
		emplist.add(new Employee(102, "Sandy Singh"));
		emplist.add(new Employee(107, "Sindi Singh"));
		
		//System.out.println(emplist);
		System.out.println("Employee Information not sorted:");
		for(Employee s: emplist)
		{
			System.out.println(s.EmpId+"   "+s.EmpName);
		}
		
		CompareEmpByEmpId com1=new CompareEmpByEmpId();
		
		emplist.sort(com1);
		System.out.println("Employee Information after sorting:");
		for(Employee s: emplist)
		{
			System.out.println(s.EmpId+"   "+s.EmpName);
		}
		

	}
	
}
