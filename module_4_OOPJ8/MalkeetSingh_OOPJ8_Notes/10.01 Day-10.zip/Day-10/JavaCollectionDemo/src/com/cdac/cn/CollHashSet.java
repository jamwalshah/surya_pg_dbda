package com.cdac.cn;

import java.util.HashSet;
import java.util.Iterator;

public class CollHashSet {

	public static void main(String[] args) {
		
		
		HashSet<Integer> hs1=new HashSet<Integer>();
		
		
		hs1.add(10);
		hs1.add(15);
		hs1.add(78);
		hs1.add(9);
		hs1.add(8);
		
		Iterator<Integer> it1=hs1.iterator();
		
		while(it1.hasNext())
		{
			System.out.println(it1.next());
		}

	}

}
