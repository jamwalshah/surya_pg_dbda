package com.cdac.cn;

import java.util.Iterator;
import java.util.TreeSet;

class Student implements Comparable<TreeSet>
{
	int RollNo;
	String Name;
	public Student(int rollNo, String name) {
		super();
		RollNo = rollNo;
	}
	@Override
	public int compareTo(TreeSet o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
public class CollTreeSetDemo2 {

	public static void main(String[] args) {
		
		Student s1=new Student(101, "ABC");
		Student s2=new Student(109, "PQR");
		Student s3=new Student(118, "ABCD");
		Student s6=new Student(160, "YYZ");
		Student s7=new Student(198, "UTY");
		
		TreeSet<Student> ts=new TreeSet<Student>();
		
		ts.add(s3);
		ts.add(s1);
		ts.add(s7);
		ts.add(s2);
		ts.add(s6);

		Iterator<Student> its=ts.iterator();
		
		while(its.hasNext())
		{
			System.out.println(its.next().RollNo+"  "+its.next().Name);
		}
		

	}

}
