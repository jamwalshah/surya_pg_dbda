package com.cdac.cn;

import java.util.ArrayList;
import java.util.TreeSet;

public class CollTreeSetDemo {

	public static void main(String[] args) {
		
		TreeSet<Integer> ts1=new TreeSet<Integer>();
		
		ts1.add(10);
		ts1.add(45);
		ts1.add(50);
		ts1.add(55);
		ts1.add(90);
		ts1.add(9);
		
		for(Integer in: ts1)
		{
			System.out.println(in);
		}
		
		ArrayList<Integer> al=new ArrayList<Integer>();
		System.out.println("ArrayList Print");
		al.addAll(ts1);
		for(Integer in: al)
		{
			System.out.println(in);
		}

	}

}
