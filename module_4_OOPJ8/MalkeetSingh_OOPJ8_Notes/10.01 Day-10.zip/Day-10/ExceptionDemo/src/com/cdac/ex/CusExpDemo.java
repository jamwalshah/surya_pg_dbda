package com.cdac.ex;

class InvalidAgeException extends Exception
{
	public InvalidAgeException(String msg) 
	{
		super(msg);
		System.out.println("Am Invalid Age Exception");
		
	}
}


public class CusExpDemo {
	
	
	public static void ValidateAge(int age) throws InvalidAgeException
	{
		if(age<18)
		{
			throw new InvalidAgeException("Age is less than 18");
		}
		else
		{
			System.out.println("Welcome To Vote");
		}
	}

	public static void main(String[] args) {


		int ag=13;
		try
		{
			CusExpDemo.ValidateAge(ag);
		}
		catch(InvalidAgeException ex)
		{
			System.out.println("Catched Exception:"+ex.getMessage());
		}
		

	}

}
