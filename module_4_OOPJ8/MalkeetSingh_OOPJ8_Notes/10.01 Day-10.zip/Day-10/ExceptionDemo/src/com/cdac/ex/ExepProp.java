package com.cdac.ex;

class Exp
{
	void M()
	{
		int a=20;
		int b=0;
		int c=a/b;
	}
	void N()
	{
		M();
	}
	void P()
	{
		try
		{
			N();
		}
		catch(ArithmeticException ex)
		{
			System.out.println("Exception Handled Here in P");
		}
	}
}

public class ExepProp {

	public static void main(String[] args) {
		
		Exp e1=new Exp();
		
		e1.P();

	}

}
