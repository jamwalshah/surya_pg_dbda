package com.cdac.main;

import java.util.Scanner;

public class Student {
	int RollNo;
	int fees;
	void SetData()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Roll No");
		RollNo=sc.nextInt();
		System.out.println("Enter Fees");
		fees=sc.nextInt();
		
	}
	void PrintRecord()
	{
		System.out.println("Student Information");
		System.out.println(RollNo+" "+fees);
	}

	public static void main(String[] args) {
		
		Student[] s1=new Student[5]; //creating five references of class student
		for(int i=0;i<s1.length;i++)
		{
			s1[i]=new Student();      //creating instances of student class and assigning them to student ref
		}
		for(int i=0;i<s1.length;i++)
		{
			System.out.println("Enter data for "+i+1+" Instance");
			s1[i].SetData();
		}
		for(int i=0;i<s1.length;i++)
		{
			s1[i].PrintRecord();
		}
		
		

	}

}
