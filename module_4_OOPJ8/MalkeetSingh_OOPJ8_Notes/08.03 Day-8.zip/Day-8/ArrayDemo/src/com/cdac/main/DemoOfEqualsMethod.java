package com.cdac.main;

public class DemoOfEqualsMethod {

	public static void main(String[] args) {

		String s=new String("Malkeet");
		String s1=new String("Malkeet");
		
		//== 
		
		if(s.equals(s1))
		{
			System.out.println("Equal");
		}
		else
		{
			System.out.println("Not Equal");
		}

	}
	public static void main1(String[] args) {

int s=20;
int s1=20;
		
		//== 
		
		if(s==s1)
		{
			System.out.println("Equal");
		}
		else
		{
			System.out.println("Not Equal");
		}

	}

}
