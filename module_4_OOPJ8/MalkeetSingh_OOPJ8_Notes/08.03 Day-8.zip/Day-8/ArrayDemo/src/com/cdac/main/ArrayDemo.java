package com.cdac.main;

import java.util.Scanner;

public class ArrayDemo {
	
	public static void PrintArray(int arr2[])
	{
		System.out.print("Array is:   ");
		for(int i:arr2 )
		{
		System.out.println(i);
		}
		
		arr2[4]=112;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int arr[]=new int[5]; //Decalartion of Array of int type with fixed size of 5 elements
	for(int i=0;i<arr.length;i++)
	{
		System.out.println("Enter a Int value");
		arr[i]=sc.nextInt();
	}
	ArrayDemo.PrintArray(arr); //passing array to PrintArray Method as a argument

	System.out.print("Array after calling Print Array Method:   ");
	for(int i:arr )
	{
	System.out.println(i);
	}
	}
}
