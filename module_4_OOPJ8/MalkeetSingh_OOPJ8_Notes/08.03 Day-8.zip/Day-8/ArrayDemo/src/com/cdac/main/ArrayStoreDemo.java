package com.cdac.main;

public class ArrayStoreDemo {

	public static void main(String[] args) {
		Object o1=new String("Malkeet");
		Object o2=new String("Saneep");
		Object o3=new String("Mahesh");
		
		Object o[]= new String[3];
		
		o[0]=new String("Malkeet");
		o[1]= new String("Singh");
		o[2]=new StringBuffer("Sandeep");
		
		//System.out.println(o1.toString()+" "+o2.toString()+" "+o3.toString());

for(int i=0;i<3;i++)
{
	System.out.println(o[i].toString());
}
	}

}
