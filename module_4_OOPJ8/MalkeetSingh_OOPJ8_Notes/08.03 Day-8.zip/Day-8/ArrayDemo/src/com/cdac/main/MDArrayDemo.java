package com.cdac.main;

import java.util.Scanner;

public class MDArrayDemo {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		int arr[][]=new int[3][3];
		for(int i=0;i<3;i++)
		{
			System.out.println("Enter the element for "+i+1+" row");
			for(int j=0;j<3;j++)
			{
				System.out.println("Enter Element");
				arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("Entered Array is:");
		outer: for(int i=0;i<3;i++)
		{
			inner: for(int j=0;j<3;j++)
			{
				System.out.print(arr[i][j]+"    ");
				break inner;
			}
			System.out.println();
			
		}
	}

}
