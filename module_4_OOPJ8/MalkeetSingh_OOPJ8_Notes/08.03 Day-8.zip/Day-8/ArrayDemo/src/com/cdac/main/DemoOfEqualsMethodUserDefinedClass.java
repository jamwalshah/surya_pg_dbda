package com.cdac.main;

class Employee
{
	int EmpId;
	String Name;
	
	
	Employee(int EmpId, String Name)
	{
		this.EmpId=EmpId;
		this.Name=Name;
	}
	
	@Override
	public boolean equals(Object o) {
		
		if(o!=null)
		{
			if(o instanceof Object)
			{
				Employee oe=(Employee)o; //Downcasting
							
				if(this.Name==oe.Name && this.EmpId==oe.EmpId)
				{
					return true;
				}
			}
		}
		return false;
		
	}
}

public class DemoOfEqualsMethodUserDefinedClass {

	public static void main(String[] args) {
		
		Employee e1=new Employee(1001,"Suresh");
		Employee e2=new Employee(1001, "Suresh");
		
		if(e1.equals(e2))
		{
			System.out.println("EQUAL");
		}
		else
		{
			System.out.println("Not Equal");
		}

	}

}
