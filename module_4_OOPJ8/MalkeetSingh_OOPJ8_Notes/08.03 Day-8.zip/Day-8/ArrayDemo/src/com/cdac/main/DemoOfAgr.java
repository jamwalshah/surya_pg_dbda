package com.cdac.main;
 
class Student
{
	private int RollNo;
	private String Name;
	
	public int getRollNo() {
		return RollNo;
	}
	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	Student(int rollno, String name)
	{
		this.RollNo=rollno;
		this.Name=name;
	}
	void showdata()
	{
		System.out.println("Roll No is:   "+RollNo);
		System.out.println(+RollNo+"    "+Name);
	}
}
class Teacher
{
	String TeachName;
	Student s;
	
	Teacher(String Name, Student s1)
	{
		s=s1;
		this.TeachName=Name;
		s.setName(s1.getName());
		s.setRollNo(s1.getRollNo());
		
	}
	void DisplayTeacher()
	{
		System.out.println("Teacher Informatio:");
		System.out.println(this.TeachName);
		System.out.println("Student Name:   "+s.getName());
		System.out.println("Student Roll No:   "+s.getRollNo());
	}
}
public class DemoOfAgr {

	public static void main(String[] args) {
	
		Student stu=new Student(1001, "Sandeep");
		//Teacher t1=new Teacher("Malkeet", stu);
		Teacher t1=new Teacher("Malkeet", new Student(1002,"Mandeep"));
		t1.DisplayTeacher();

	}

}
