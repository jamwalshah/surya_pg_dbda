package com.cdac.main;

public class PassByValueDemo {
	
	
	static void AddNum(int p, int q) {

		System.out.println(p+q);
		
		p=30;
		
	}
	public static void main(String[] args) {

		int a=10;
		int b=20;
		System.out.println("Value of a and b before passing"+a+" "+b);
		PassByValueDemo.AddNum(a,b);
		System.out.println("Value of a and b after passing"+a+" "+b);

	}



}
