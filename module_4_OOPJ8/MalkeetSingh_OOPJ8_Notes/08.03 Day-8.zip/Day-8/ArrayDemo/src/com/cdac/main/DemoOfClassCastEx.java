package com.cdac.main;

class A
{
	int a;
}
class B extends A
{
	int b;
}

public class DemoOfClassCastEx {

	public static void main(String[] args) {
		
		A a1=new A();
		
		B b1=new B();
		
		B b2=(B)a1;
		
		b2.b=20;
		
		System.out.println("b is:"+b2.a);
		
		
		
		
		// TODO Auto-generated method stub

	}

}
