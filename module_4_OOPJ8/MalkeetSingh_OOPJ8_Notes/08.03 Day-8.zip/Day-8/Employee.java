class Employee{
    private String name;
    private int empid;
    private float salary;
    public Employee(String name, int empid, float salary) {
    this.name = name;
    this.empid = empid;
    this.salary = salary;
    }
    @Override
    public boolean equals( Object obj ) {
    if( obj != null ) {
    Employee other = (Employee) obj; //Downcasting
    if( this.empid == other.empid )
    return true;
    }
    return false;
    }
   
    }
    class Program {
    public static void main(String[] args) {
    Employee emp1 = new Employee("Sandeep", 3778, 45000.50f );
    Employee emp2 = new Employee("Sandeep", 3778, 45000.50f );
    if( emp1.equals(emp2) )
    System.out.println("Equal");
    else
    System.out.println("Not Equal");
    //Not Equal
    }
    public static void main1(String[] args) {
    Employee emp1 = new Employee("Sandeep", 3778, 45000.50f );
    Employee emp2 = new Employee("Sandeep", 3778, 45000.50f );
    if( emp1 == emp2 ) //OK: Comparing state of references
    System.out.println("Equal");
    else
    System.out.println("Not Equal");
    //Not Equal
    }
    }