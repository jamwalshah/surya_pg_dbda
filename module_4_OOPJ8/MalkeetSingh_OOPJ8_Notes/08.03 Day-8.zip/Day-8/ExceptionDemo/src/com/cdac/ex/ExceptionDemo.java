package com.cdac.ex;

public class ExceptionDemo {

	public static void main(String[] args) {
		
		
		int a=10;
		int b=5;
		int c=0;
		try
		{
			c=a/b;
		}
		
		catch (RuntimeException ex) {
			
			System.out.println("Exception Catched:"+ex.getMessage());
		}
		
		finally {
			System.out.println(" I am Finally");
		}

		
		System.out.println("Result:    "+c);
		
		
		System.out.println("Hello Am Executing");
		
		System.out.println("Program Stopped Norammly......");
		

	}

}
